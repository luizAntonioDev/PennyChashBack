﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Penny.Web.AspNet.Controllers
{
    public class AcessoController : Controller
    {

        private IAcessoRespository _acessoRepository;

        public AcessoController(IAcessoRespository acessoRespository)
        {
            _acessoRepository = acessoRespository;
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}