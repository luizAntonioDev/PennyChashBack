﻿namespace Penny.Web.AspNet.Controllers
{
    internal interface IAcessoRespository
    {
    }
}