﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Penny.Web.AspNet.Models
{
    public enum Estado
    {
	RO,
	AC,
	AM,
	RR,
	PA,
	AP,
	TO,
	MA,
	PI,
	CE,
	RN,
	PB,
	PE,
	AL,
	SE,
	BA,
	MG,
	ES,
	RJ,
	SP,
	PR,
	SC,
	RS,
	MS,
	MT,
	GO,
	DF
    }
}
