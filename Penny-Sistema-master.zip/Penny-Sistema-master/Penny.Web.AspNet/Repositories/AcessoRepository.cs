﻿using Penny.Web.AspNet.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Penny.Web.AspNet.Repositories
{
    public class AcessoRepository : IAcessoRepository
    {
        private PennyContext _context;

        public AcessoRepository(PennyContext context)
        {
            _context = context;
        }
    }
}

    
