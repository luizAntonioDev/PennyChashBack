﻿using Penny.Web.AspNet.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Penny.Web.AspNet.Repositories
{
    public class UsuarioRepository : IUsuarioRepository
    {
        private PennyContext _context;

        public UsuarioRepository(PennyContext context)
        {
            _context = context;
        }
    }
}
