﻿using Penny.Web.AspNet.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Penny.Web.AspNet.Repositories
{
    public class ProdutoRepository : IProdutoRepository
    {
        private PennyContext _context;

        public ProdutoRepository(PennyContext context)
        {
            _context = context;
        }
    }
}
